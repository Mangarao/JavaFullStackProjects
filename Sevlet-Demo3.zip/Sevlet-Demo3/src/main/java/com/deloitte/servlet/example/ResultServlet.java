package com.deloitte.servlet.example;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/result")
public class ResultServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username="";
        //using Cookies
		/*
		 * Cookie[] cookies = request.getCookies(); username = cookies[0].getValue();
		 * username+="mihi";
		 */
        //using Hidden Form fields && URL Rewriting
		/* username=request.getParameter("username"); */
        
        //Using HttpSession
		/*
		 * HttpSession session = request.getSession(false); if (session == null) {
		 * response.sendRedirect("login.html"); return; }
		 * 
		 * username = (String) session.getAttribute("username");
		 */
        PrintWriter pw = response.getWriter();
        response.setContentType("text/html");
        pw.print( username.toUpperCase() + ",");
        String userAnswer = request.getParameter("answer").toLowerCase();
        if ("delhi".equals(userAnswer)) {
        	pw.println("You have answered correctly");
            pw.println("<a href=\"logout\">Logout</a><br>"); 
            pw.println("<a href='javaQuiz'>Click here for Java Quiz</a>");
        } else {
        	pw.println("Sorry, that's not the right answer! ");
            pw.println("<br><a href=\"logout\">Logout</a>");
        }
        pw.close();
    }
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	doPost(req, resp);
    }
    
}
