package com.deloitte.servlet.example;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.annotation.Documented;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/quiz")
public class QuizServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	PrintWriter pw = response.getWriter();
    	response.setContentType("text/html");
        String username = request.getParameter("username");
        
        //Using Cookies
		/*
		 * Cookie ck=new Cookie("username", username); response.addCookie(ck);
		 */
     
        
        //Using HttpSession
		/*
		 * HttpSession session = request.getSession();
		 * session.setAttribute("username", username);
		 */
        
        
        pw.println("<h1>Quiz Time, " + username + "!</h1>");
        pw.println("<form action='result' method='post'>");
        pw.println("<p>Question: What is the capital of India?</p>");
        pw.println("<input type='text' name='answer' required>");
        //Using HiddenForm Fields
		/* pw.println("<input type='hidden' name='username' value='"+username+"'>"); */
        pw.println("<button type='submit'>Submit Answer</button>");
        pw.println("</form>");
        
        //Using URL rewriting
		/*
		 * pw.println("<a href='result?username="
		 * +username+"&answer=Delhi'>Submit your answer</a>");
		 */
    }
}
