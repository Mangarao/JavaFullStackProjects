Session Tracking:
Session tracking in Servlets is a way to maintain user data across multiple requests in a web application. Since HTTP is stateless, session tracking allows the server to remember users between requests

Session Tracking Techniques:
Session tracking = Temporary memory of the server for each user.
It helps maintain a smooth, personalized experience

1. Cookies
Small pieces of data stored on the client-side by the web browser.
Pros - Easy to implement; <br> - Widely supported by browsers; <br> - Can persist across sessions.
Cons - Limited storage size; <br> - Can be disabled by users; <br> - Security concerns (e.g., XSS).


2. Hidden Form Fields
Session data is stored in hidden fields of forms and passed with form submissions.
Pros - Simple to implement; <br> - No need for client-side storage.
Cons - Only works with form submissions; <br> - Can be tampered with if not properly secured.


3. URL Rewriting
Session data is passed via query strings in the URL.
Pros - Easy to implement; <br> - No need for client-side storage.
Cons - Can expose sensitive data in URLs; <br> - Can make URLs messy and hard to read.


4. Http Session:x
Stores session data on the server, with a session ID stored in the client-side.
Pros- More secure as data is stored on the server; <br> - Can store large amounts of data.
Cons - Requires server resources; <br> - Can be complex to implement and manage.

Real-Time Examples of Session Tracking
1. Online Shopping (Amazon, Flipkart)

Adds items to cart
Cart remembers items across pages
Session stores cart data
2. User Login (Gmail, Facebook)

Logs in once
Navigates inbox, settings, etc.
Session tracks login state
3. Food Ordering (Swiggy, Zomato)

Selects items, address, payment mode
Doesn’t lose selection while browsing
Session holds order flow
4. Online Exams/Quizzes

Saves answers question by question
Tracks timer and student info
Session ensures continuity
5. Movie Ticket Booking (BookMyShow)

Selects movie, seats, time, snacks
Doesn’t lose info if you go back or forward
Session maintains booking data


Realtime Use Case:
An online quiz system where users must enter their username before starting the quiz. 
The system displays one question, track username using Cookies/URL rewriting/Hidden Form fields/HTTP sessions, and shows the result along with the username at the end.
Additionally, users can log out to invalidate the session.

Project Name: Serlvet-Demo3 (Online Quiz)
In this example, we are demonstrating all four session tracking techniques by uncommenting the relevant code one by one.
Components:

login.html: Captures the username.
QuizServlet: Displays quiz question and option to click on Enter button for quiz. Track username using session tracking techniques
ResultServlet: Displays the username and quiz results.
LogoutServlet: Invalidates the session and logs the user out.
JavaQuizServlet: To redirect to the quiz in external application

Hands-on Tasks:
Task1:
Cookie Login

On login, create a cookie with username.
On next visit, read cookie and greet user automatically.

Task 2:
Multi-Page Form With Hidden Fields

Create 2-step form (Step 1: name, Step 2: age).
Use hidden fields to retain Step 1 data.

Task 3:
 URL Rewriting Example

Send session data using URL like next?user=John.
Show how URL rewriting can simulate session.

Task 4:
Cart Management Using Session

Store selected product names in HttpSession.
Display cart items on a different servlet.

Task 5:
Session Timeout Demo

Set session timeout to 1 minute.
Redirect to timeout.jsp after session expires.

Task 6:
 LogoutServlet

Create a LogoutServlet.
Invalidate session and redirect to login page.

Task 7:
AdminPanelServlet

Allow access only if session attribute role=admin exists.
Else redirect to access-denied.jsp.

Task 8:
AutoLoginServlet

On login, store username in cookie.
Autofill login form next time.