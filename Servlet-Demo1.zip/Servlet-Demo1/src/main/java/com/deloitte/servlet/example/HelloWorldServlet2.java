package com.deloitte.servlet.example;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet("/helloGeneric2")
public class HelloWorldServlet2 extends GenericServlet {
    @Override
    public void init() throws ServletException {
        super.init();
        // Initialization code
        System.out.println("HelloWorldServlet2 initialized");
    }

    @Override
    public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<h1>Hello, World from HelloWorldServlet2!</h1>");
    }

    @Override
    public void destroy() {
        super.destroy();
        // Cleanup code
        System.out.println("HelloWorldServlet2 destroyed");
    }
}
