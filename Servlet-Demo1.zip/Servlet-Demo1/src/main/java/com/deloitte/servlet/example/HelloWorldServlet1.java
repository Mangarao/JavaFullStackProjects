package com.deloitte.servlet.example;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet("/helloInterface2")
public class HelloWorldServlet1 implements Servlet {

    private ServletConfig config;

    @Override
    public void init(ServletConfig config) throws ServletException {
        this.config = config;
        // Initialization code
        System.out.println("HelloWorldServlet1 initialized");
    }

    @Override
    public ServletConfig getServletConfig() {
        return this.config;
    }

    @Override
    public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<h1>Hello, World from HelloWorldServlet1!</h1>");
    }

    @Override
    public String getServletInfo() {
        return "HelloWorldServlet1";
    }

    @Override
    public void destroy() {
        // Cleanup code
        System.out.println("HelloWorldServlet1 destroyed");
    }
}