package com.deloitte.servlet.example;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.deloitte.servlet.example.dao.UserDAO;

public class UserRegistrationServlet extends HttpServlet {
    private String appName;
    private String supportEmail;
    private String contactNumber;

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        ServletContext context = config.getServletContext();
        appName = context.getInitParameter("app-name");
        supportEmail = config.getInitParameter("support-email");
        contactNumber = config.getInitParameter("contact-number"); 
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String email = req.getParameter("email");

        try {
            try (Connection connection = new UserDAO().getConnection()) {
                String sql = "INSERT INTO users (username, password, email) VALUES (?, ?, ?)";
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                    statement.setString(1, username);
                    statement.setString(2, password);
                    statement.setString(3, email);
                    int rowsInserted = statement.executeUpdate();
                    resp.setContentType("text/html");
                    PrintWriter out = resp.getWriter();
                    if (rowsInserted > 0) {
                        out.println("Hello, Mr. "+username+", you have been registered successfully!, Welcome to <b style='color:blue'> "+appName+"</b>");
                    } else {
                        out.println("Failed to register user.");
                    }
                    out.println("<br>Support Email: <b>" + supportEmail+"</b>");
                    out.println("<br>Contact Number: <b>" + contactNumber+"</b>");
                }
            }
        } catch (SQLException e) {
            throw new ServletException("Database connection problem", e);
        } 
    }
}
