package com.deloitte.servlet.example;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UserRegistrationServlet extends HttpServlet {
    private String dbUrl;
    private String dbUsername;
    private String dbPassword;
    private String supportEmail;
    private String contactNumber;

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        ServletContext context = config.getServletContext();
        dbUrl = context.getInitParameter("database-url");
        dbUsername = context.getInitParameter("database-username");
        dbPassword = context.getInitParameter("database-password");
        supportEmail = config.getInitParameter("support-email");
        contactNumber = config.getInitParameter("contact-number");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String email = req.getParameter("email");

        try {
            // Register the driver class and establish the connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection connection = DriverManager.getConnection(dbUrl, dbUsername, dbPassword)) {
                String sql = "INSERT INTO users (username, password, email) VALUES (?, ?, ?)";
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                    statement.setString(1, username);
                    statement.setString(2, password);
                    statement.setString(3, email);
                    int rowsInserted = statement.executeUpdate();
                    resp.setContentType("text/html");
                    PrintWriter out = resp.getWriter();
                    if (rowsInserted > 0) {
                        out.println("Hello, Mr. "+username+", you have been registered successfully!");
                    } else {
                        out.println("Failed to register user.");
                    }
                    out.println("<br>Support Email: " + supportEmail);
                    out.println("<br>Contact Number: " + contactNumber);
                }
            }
        } catch (ClassNotFoundException e) {
            throw new ServletException("Driver class not found", e);
        } catch (SQLException e) {
            throw new ServletException("Database connection problem", e);
        }
    }
}
