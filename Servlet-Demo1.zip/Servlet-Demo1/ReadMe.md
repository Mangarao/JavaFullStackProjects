Java Servlets: 
Prerequisites:
•	Java SE (Core Java Knowledge)
•	Web Technologies (HTML, CSS & JS Knowledge)
•	SQL (Oracle or MySQL)
•	MySQL server & MySQL Workbench: MySQL Installer
•	IDE: Eclipse for Java EE Developers: Eclipse Downloads
•	Web Server: Apache Tomcat Server (version 9): Tomcat Downloads
•	Debugging Skills
Overview of Java Web Applications:
Java web applications are composed of various components including:
•	Frontend: HTML, CSS, JS, Images
•	Backend: Servlets, JSP, Java classes
•	Database: SQL files
•	Configuration: XML files, properties files
•	Libraries: JAR files
Famous Web Applications:
Examples of popular web applications include:
•	Google Docs, Slack, Facebook, Twitter, WhatsApp Web, Zoom, Google Maps, Uber, Paytm, Zomato, Swiggy, Ola, Flipkart, BigBasket, BookMyShow, Gaana, Hotstar, BYJU'S
Ways of Servlet Creation:
1.	By Implementing Servlet interface
2.	By Extending GenericServlet class
3.	By Extending HttpServlet class


Steps for Creating a Servlet/Web Application:
1.	Create Directory Structure
2.	Create a Servlet
3.	Configure the Servlet
4.	Deploy the Project on Server
5.	Start the Server and Access the Servlet
Servlet Config & Servlet Context:
•	ServletConfig: Used to pass configuration information to a servlet during initialization. Each servlet has its own ServletConfig object.
•	ServletContext: Provides context information to servlets. It is used to fetch database connection details and other context-wide parameters.
Project Name: Servlet-Demo1
This project covers various aspects of servlet creation, registration, lifecycle methods, welcome-file-lists, data persistence from UI with Servlet, JDBC & MySQL, ServletConfig, and ServletContext.
1. HelloWorldServlet1:
•	Creation by implementing the Servlet interface.
•	Overriding lifecycle methods with initialization and cleanup code.
•	Configurations: 
o	XML-based configuration: URL pattern /helloInterface1
o	Annotation-based configuration: URL pattern /helloInterface2
2. HelloWorldServlet2:
•	Creation by extending GenericServlet.
•	Annotation-based configuration.
•	URL pattern: /helloGeneric2
3. HelloWorldServlet3:
•	Creation by extending HttpServlet.
•	Annotation-based configuration.
•	URL pattern: /helloHttp3

Real-time Use Case:
A company might use this setup to allow users to register on their website. The servlet fetches database connection details from ServletContext and uses them to insert user details into the database securely. Additionally, it uses ServletConfig to fetch support contact details, which can be displayed to the user upon successful registration. This approach ensures that sensitive database credentials are managed centrally and not hard-coded into the servlet, while also providing relevant support information to the users.

4. User Registration:
•	userRegister.html: HTML form for user registration.
•	UserRegistrationServlet.java: Servlet to handle user registration.
•	Covers ServletConfig, ServletContext, and real-time use case to persist user data from UI to DB using Servlets and JDBC.

HTTP Status Codes:
Status Code	Meaning
Informational Responses (100-199)	
100 Continue	The server has received the request headers, and the client should proceed to send the request body.
101 Switching Protocols	The requester has asked the server to switch protocols, and the server has agreed to do so.
Successful Responses (200-299)	
200 OK	The request has succeeded.
201 Created	The request has been fulfilled, resulting in the creation of a new resource.
202 Accepted	The request has been accepted for processing, but the processing has not been completed.
204 No Content	The server successfully processed the request, and is not returning any content.
Redirection Messages (300-399)	
301 Moved Permanently	The requested resource has been assigned a new permanent URI.
302 Found	The requested resource resides temporarily under a different URI.
304 Not Modified	The resource has not been modified since the version specified by the request headers.
Client Error Responses (400-499)	
400 Bad Request	The server cannot or will not process the request due to an apparent client error.
401 Unauthorized	Authentication is required and has failed or has not yet been provided.
403 Forbidden	The request was valid, but the server is refusing action.
404 Not Found	The requested resource could not be found but may be available in the future.
405 Method Not Allowed	A request method is not supported for the requested resource.
Server Error Responses (500-599)	
500 Internal Server Error	An unexpected condition was encountered.
501 Not Implemented	The server either does not recognize the request method, or it lacks the ability to fulfill the request.
502 Bad Gateway	The server was acting as a gateway or proxy and received an invalid response from the upstream server.
503 Service Unavailable	The server is currently unavailable (because it is overloaded or down for maintenance).
504 Gateway Timeout	The server was acting as a gateway or proxy and did not receive a timely response from the upstream server.

Hands-on Tasks:
Task 1: Dynamic Greeting Servlet
•	Accept first name and last name as query parameters.
•	Display a message with full name like "Good morning, John!".
•	Use request.getParameter() in doGet().
Task 2: Feedback Form
•	Create form to accept name, email, feedback.
•	Show a thank you page with submitted info.
Task 3: Display Server Info
•	Display server name, port, and servlet version.
•	Use request.getServerName(), getServerPort(), and getServletContext().getMajorVersion().
Task 4: InstituteInfoServlet (ServletConfig)
•	Configure init parameters like institute name and contact.
•	Access them using getServletConfig().getInitParameter().
Task 5: AppInfoServlet (ServletContext)
•	Read a context-wide init param like developerName.
•	Show the param on the browser.
•	Use getServletContext().getInitParameter().
Task 6: VisitorCounterServlet
•	Track number of total hits using a context attribute.
•	Increment it each time servlet is accessed.
•	Store and retrieve value using ServletContext.setAttribute() and getAttribute().
Task 7: File Download Servlet
•	Let user click and download a PDF.
•	Set headers using response.setHeader().
Task 8: Return JSON String with Product Info
•	Set content-type as application/json




