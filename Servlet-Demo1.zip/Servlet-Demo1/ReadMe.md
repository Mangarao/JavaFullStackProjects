Prerequisites:
Java SE (Core Java Knowledge)
Web Technologies (HTML, CSS & JS Knowledge)
SQL (Oracle or MySql)
   MySQL server & MySQL Workbench  https://dev.mysql.com/downloads/installer/
IDE 
    Eclipse for Java EE Developers: https://www.eclipse.org/downloads/packages/
Web Server
    Apache Tomcat Server (version 9):  https://tomcat.apache.org/download-90.cgi
Debugging Skills

Overview of Java Web Applications:
Java web applications are composed of various components including:

Frontend: HTML, CSS, JS, Images
Backend: Servlets, JSP, Java classes
Database: SQL files
Configuration: XML files, properties files
Libraries: JAR files

Famous Web Applications:
Examples of popular web applications include:

Google Docs, Slack, Facebook, Twitter, WhatsApp Web, Zoom, Google Maps, Uber
Paytm, Zomato, Swiggy, Ola, Flipkart, BigBasket, BookMyShow, Gaana, Hotstar, BYJU'S

Steps for Creating a Servlet/Web Application:

Create Directory Structure
Create a Servlet
Configure the Servlet
Deploy the Project on Server
Start the Server and Access the Servlet

Servlet Config & Servlet Context:

ServletConfig: Used to pass configuration information to a servlet during initialization. Each servlet has its own ServletConfig object.
ServletContext: Provides context information to servlets. It is used to fetch database connection details and other context-wide parameters.

Real-time Use Case:
A company might use this setup to allow users to register on their website. The servlet fetches database connection details from ServletContext and uses them to insert user details into the database securely. Additionally, it uses ServletConfig to fetch support contact details, which can be displayed to the user upon successful registration. This approach ensures that sensitive database credentials are managed centrally and not hard-coded into the servlet, while also providing relevant support information to the users.

Project name: Servlet-Demo1
This project covers various aspects of servlet creation, registration, lifecycle methods, welcome-file-lists, data persistence from UI with Servlet, JDBC & MySQL, ServletConfig, and ServletContext.

1. HelloWorldServlet1:

Creation by i mplementing the Servlet interface.
Overriding lifecycle methods with initialization and cleanup code.
Configurations:

XML-based configuration: URL pattern /helloInterface1
Annotation-based configuration: URL pattern /helloInterface2


2. HelloWorldServlet2:

Creation by extending GenericServlet.
Annotation-based configuration.
URL pattern: /helloGeneric2



3. HelloWorldServlet3:

Creation by extending HttpServlet.
Annotation-based configuration.
URL pattern: /helloHttp3


4. User Registration:

userRegister.html: HTML form for user registration.
UserRegistrationServlet.java: Servlet to handle user registration.
Covers ServletConfig, ServletContext, and real-time use case to persist user data from UI to DB using Servlets and JDBC.
     
Hands-on Tasks:

Task 1:
Dynamic Greeting Servlet

Accept first name and last name as query parameters.
Display a message with full name like "Good morning, John!".
Use request.getParameter() in doGet().

Task 2: 
Feedback Form

Create form to accept name, email, feedback.
Show a thank you page with submitted info.

Task 3:
Display server name, port, and servlet version.
Use request.getServerName(), getServerPort(), and getServletContext().getMajorVersion().

Task 4:
InstituteInfoServlet (ServletConfig)

Configure init parameters like institute name and contact.
Access them using getServletConfig().getInitParameter().

Task 5:
AppInfoServlet (ServletContext)

Read a context-wide init param like developerName.
Show the param on the browser.
Use getServletContext().getInitParameter().

Task 6:
VisitorCounterServlet

Track number of total hits using a context attribute.
Increment it each time servlet is accessed.
Store and retrieve value using ServletContext.setAttribute() and getAttribute().


Task 7:
File Download Servlet

Let user click and download a PDF.
Set headers using response.setHeader().

Task 8:
Return JSON string with product info.
Set content-type as application/json.