package com.example.taskmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TmsBeApplication {

	public static void main(String[] args) {
		SpringApplication.run(TmsBeApplication.class, args);
	}

}
