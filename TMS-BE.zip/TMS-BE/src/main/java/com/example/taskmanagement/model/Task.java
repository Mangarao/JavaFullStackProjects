package com.example.taskmanagement.model;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Task {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String title;
	private String description;
	//"TO-DO", "IN-PROGRESS", "PENDING", "COMPLETE"
    private String status;
    private LocalDateTime addedDate;
    
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

	public Task() {
		this.setAddedDate(LocalDateTime.now());
        this.status = "TO-DO";
	}


	public Task(Long id, String title, String description, String status, LocalDateTime addedDate, User user) {
		super();
		this.id = id;
		this.title = title;
		this.description = description;
		this.status = status;
		this.addedDate = addedDate;
		this.user = user;
	}




	public Long getId() {
		return id;
	}



	public void setId(Long id) {
		this.id = id;
	}



	public String getTitle() {
		return title;
	}



	public void setTitle(String title) {
		this.title = title;
	}



	public String getDescription() {
		return description;
	}



	public void setDescription(String description) {
		this.description = description;
	}



	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}



	public LocalDateTime getAddedDate() {
		return addedDate;
	}



	public void setAddedDate(LocalDateTime addedDate) {
		this.addedDate = addedDate;
	}



	public User getUser() {
		return user;
	}



	public void setUser(User user) {
		this.user = user;
	}
	
	

	
	

}