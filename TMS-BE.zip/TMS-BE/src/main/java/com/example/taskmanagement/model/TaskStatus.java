package com.example.taskmanagement.model;

public enum TaskStatus {
    TO_DO("TO-DO"),
    IN_PROGRESS("In-Progress"),
    PENDING("Pending"),
    COMPLETE("Complete");

    private final String displayName;

    TaskStatus(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
