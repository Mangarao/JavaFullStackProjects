package com.example.taskmanagement.service;


import com.example.taskmanagement.model.User;
import com.example.taskmanagement.repository.UserRepository;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
 private final UserRepository userRepository;

 @Autowired
 public UserService(UserRepository userRepository) {
     this.userRepository = userRepository;
 }

 public User registerUser(User user) {
     return userRepository.save(user);
 }

 public User findByUsername(String username) {
     return userRepository.findByUsername(username);
 }
 
 public User findById(Long userId) {
     Optional<User> user = userRepository.findById(userId);
     if(user.isPresent()) {
    	 return user.get();
     }
     return null;
 }
}
