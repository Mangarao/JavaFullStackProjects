package com.gcet.javaee.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/loginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String uname = request.getParameter("uname");
		String pwd = request.getParameter("pwd");
		PrintWriter pw = response.getWriter();
		if("shreya".equals(uname) && "shreya123".equals(pwd)) {
//			RequestDispatcher rd = request.getRequestDispatcher("/welcomeServlet");
//			rd.forward(request, response);
			HttpSession session = request.getSession(true);
			session.setAttribute("un", uname);
			response.sendRedirect("welcomeServlet");
		}else {
			response.setContentType("text/html");
			RequestDispatcher rd = request.getRequestDispatcher("/login.html");
			response.getWriter().println("Invalid Credentials");
			rd.include(request, response);
			//pw.println("Login is failed, please try again");
		}
		
	}

}
