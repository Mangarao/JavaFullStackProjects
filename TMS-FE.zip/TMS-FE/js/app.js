// app.js
// This file contains the JavaScript code for handling user authentication and task management.
// It includes functions for login, registration, task creation, task editing, and task deletion.
// It also handles displaying tasks and updating the UI accordingly.
// Ensure the DOM is fully loaded before executing any scripts
// and that the user is authenticated before allowing access to task management features.
// Use strict mode for better error handling
//'use strict';

document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('login-form');
    const registrationForm = document.getElementById('registration-form');
    const taskForm = document.getElementById('task-form');
    const taskList = document.getElementById('task-list');
    const logoutButton = document.getElementById('logout-button');
   
    let currentUser = null;
    const storedUser = localStorage.getItem('currentUser');
    try {
        currentUser = storedUser ? JSON.parse(storedUser) : null;
    } catch (error) {
        console.error('Error parsing stored user:', error);
        currentUser = null;
    }

    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            // Handle login
            const username = document.getElementById('login-username').value;
            const password = document.getElementById('login-password').value;
            loginUser(username, password);
        });
    }


    if (registrationForm) {
        registrationForm.addEventListener('submit', (e) => {
            e.preventDefault();
            // Handle registration
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            // Validate password and confirm password match
            if (password.length < 6) {
                alert('Password must be at least 6 characters long!');
                return; // Prevent form submission and retain the same page
            }
            const confirmPassword = document.getElementById('confirm-password').value;
            if (password !== confirmPassword) {
                event.preventDefault();
                alert('Passwords do not match!');
                return; // Prevent form submission and retain the same page
            }
            registerUser(username, password);
        });
    }

    if (logoutButton) {
        logoutButton.addEventListener('click', () => {
            localStorage.removeItem('currentUser');
            window.location.href = 'login.html';
        });
    }

    if (taskForm) {
        taskForm.addEventListener('submit', (e) => {
            e.preventDefault();
            // Handle task creation
            const title = document.getElementById('task-title').value;
            const description = document.getElementById('task-description').value;
            createTask(title, description);
        });
    }

    function loginUser(username, password) {
        fetch('http://localhost:8888/users/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        })
        .then(response => {
           
            if (!response.ok) {
                //display the response message on the web page
                return response.json().then(data => {
                    alert(data.message || 'Login failed!');
                    throw new Error('Network response was not ok');
                });
            }
            return response.json();
        })
        .then(user => {
            currentUser = user;
            localStorage.setItem('currentUser', JSON.stringify(currentUser));
            window.location.href = 'tasks.html';
        })
        .catch(error => console.error('Error logging in:', error));
    }

    function registerUser(username, password) {
        fetch('http://localhost:8888/users/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(user => {
            console.log('User registered:', user);
            window.location.href = 'login.html';
        })
        .catch(error => console.error('Error registering:', error));
    }

    function createTask(title, description) {
        const currentUser = JSON.parse(localStorage.getItem('currentUser'));
        const taskData = {
            title,
            description
        };
        fetch(`http://localhost:8888/tasks?userId=${currentUser.id}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(taskData)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(task => {
            addTaskToList(task);
        })
        .catch(error => console.error('Error creating task:', error));
    }

    function addTaskToList(task) {
        const li = document.createElement('li');
        li.innerHTML = `
            <strong>Task ID: ${task.id}</strong> - ${task.title} - ${task.description} <br>
            Status: ${task.status} <br>
            Added on: ${new Date(task.addedDate).toLocaleString()} <br>
            <button onclick="markTaskComplete(${task.id})">Mark Complete</button>
            <button onclick="editTask(${task.id})">Edit</button>
            <button onclick="deleteTask(${task.id})">Delete</button>
        `;
        taskList.appendChild(li);
    }

    window.markTaskComplete = function(id) {
        fetch(`http://localhost:8888/tasks/${id}/complete`, {
            method: 'PUT'
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(task => {
            updateTaskInList(task);
        })
        .catch(error => console.error('Error marking task complete:', error));
    };

    window.editTask = function(id) {
        const newTitle = prompt('Enter new title:');
        const newDescription = prompt('Enter new description:');
        if (newTitle && newDescription) {
            fetch(`http://localhost:8888/tasks/${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ title: newTitle, description: newDescription })
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(task => {
                updateTaskInList(task);
            })
            .catch(error => console.error('Error editing task:', error));
        }
    };

    window.deleteTask = function(id) {
        fetch(`http://localhost:8888/tasks/${id}`, {
            method: 'DELETE'
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            removeTaskFromList(id);
        })
        .catch(error => console.error('Error deleting task:', error));
    };

    function updateTaskInList(task) {
        const taskItems = taskList.getElementsByTagName('li');
        for (let item of taskItems) {
            if (item.innerHTML.includes(`markTaskComplete(${task.id})`)) {
                item.innerHTML = `
                    <strong>Task ID: ${task.id}</strong> - ${task.title} - ${task.description} <br>
                    Status: ${task.status} <br>
                    Added on: ${new Date(task.addedDate).toLocaleString()} <br>
                    <button onclick="markTaskComplete(${task.id})">Mark Complete</button>
                    <button onclick="editTask(${task.id})">Edit</button>
                    <button onclick="deleteTask(${task.id})">Delete</button>
                `;
                break;
            }
        }
    }

    function removeTaskFromList(id) {
        const taskItems = taskList.getElementsByTagName('li');
        for (let item of taskItems) {
            if (item.innerHTML.includes(`markTaskComplete(${id})`)) {
                taskList.removeChild(item);
                break;
            }
        }
    }

    // Fetch and display tasks from backend
    if (currentUser) {
        fetchTasks();
    }

    function fetchTasks() {
        fetch('http://localhost:8888/tasks/user/' + currentUser.id)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(tasks => {
                tasks.forEach(task => {
                    addTaskToList(task);
                });
            })
            .catch(error => console.error('Error fetching tasks:', error));
    }
});


