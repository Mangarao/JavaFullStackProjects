✅ Step-by-Step Angular App Creation
1. Install Angular CLI (if not already installed)
npm install -g @angular/cli

2. Create Angular Project
Command to create non-standalone-app
ng new TODOS-ANGULAR --no-standalone
cd TODOS-ANGULAR

Choose Yes for routing and use CSS or SCSS as per your preference.

🧱 Application Structure and Files
3. Generate Components
ng generate component username
ng generate component todo
ng generate component top-todos


Step-by-step guide to deploy your Angular application to an Amazon S3 bucket and make it publicly accessible.

Summary of Key Steps:
1.	Build your React app (npm run build).
2.	Create an S3 bucket and configure for static website hosting.
3.	Upload the build/ folder to the bucket.
4.	Set permissions for public access via bucket policy.
5.	Configure static website hosting in the S3 bucket settings.
6.	Access your website using the S3 endpoint URL or configure a custom domain.
Follow the Detailed steps here:

1. Build the Angular App
ng build --configuration production
This creates a dist/angular-todo-app/ folder.
Step 2: Create an S3 Bucket
1.	Sign in to your AWS Management Console.
2.	Navigate to S3 by typing "S3" in the search bar and selecting it.
3.	Click on the Create bucket button.
4.	Set the Bucket Name (e.g., my-react-app) which should be unique and select a region (choose the closest region to your users).
5.	In the Bucket Settings for Block Public Access, uncheck the option that blocks all public access, as we want the files to be publicly accessible.
6.	Click on Create Bucket.
Step 3: Upload Your Build Files to the S3 Bucket
1.	Go to the S3 Dashboard.
2.	Select the newly created bucket.
3.	Click on Upload.
4.	In the Upload window, Upload the contents of the dist/angular-todo-app/ (Where you can see index.html ) folder to the S3 bucket.
5.	Click on Next and then Upload to complete the upload process.
Step 4: Set Permissions for Public Access
1.	Once the files are uploaded, select your bucket and go to the Permissions tab.
2.	In the Bucket Policy section, click Edit.
3.	Add the following policy to allow public access to the files in your S3 bucket. Replace your-bucket-name with the name of your bucket:
Json:
 {
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "PublicReadGetObject",
      "Effect": "Allow",
      "Principal": "*",
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::your-bucket-name/*"
    }
  ]
}
4.	Save policy
Step 5: Configure Bucket for Static Website Hosting
1.	Go to the Properties tab of your S3 bucket.
2.	Scroll down to the Static website hosting section and click Edit.
3.	Select Enable.
4.	In the Index document field, enter index.html.
5.	In the Error document field, enter index.html (this will help with routing for single-page apps).
6.	Click Save changes.
Step 6: Access Your Website
1.	Once the bucket is configured for static website hosting, you’ll see an endpoint URL under the Static website hosting section (it will look like http://your-bucket-name.s3-website-region.amazonaws.com).
Ex: http://angular-app-by-manga.s3-website.eu-north-1.amazonaws.com 

2.	You can now access your Angular app by navigating to this URL.
Step 7: (Optional) Set up a Custom Domain (Optional)
To use a custom domain for your Angular app, you need to:
1.	Purchase or set up a domain (e.g., through Route 53 or any other domain registrar).
2.	In your domain registrar's DNS settings, create a CNAME record pointing to your S3 website endpoint.
For example, if you want your website to be accessible via www.yourdomain.com, create a CNAME record like this:
Name: www
Value: your-bucket-name.s3-website-region.amazonaws.com
1.	Once the DNS settings propagate (it can take up to 48 hours), your website should be accessible through your custom domain.
Step 8: (Optional) Use CloudFront for SSL and Faster Access (Optional)
If you'd like your Angular app to be accessible via HTTPS, you can use Amazon CloudFront to create a CDN (Content Delivery Network) distribution:
1.	Go to CloudFront in the AWS Management Console.
2.	Click Create Distribution.
3.	Choose Web and set the Origin Domain Name to your S3 bucket’s website endpoint.
4.	Set up an SSL certificate (you can use Amazon’s ACM for a free SSL certificate).
5.	Once the CloudFront distribution is created, you’ll get a new URL (it will look something like d1234abcd.cloudfront.net). You can then point your custom domain to this CloudFront URL.





# TodosAngular

This project was generated using [Angular CLI](https://github.com/angular/angular-cli) version 19.2.11.

## Development server

To start a local development server, run:

```bash
ng serve
```

Once the server is running, open your browser and navigate to `http://localhost:4200/`. The application will automatically reload whenever you modify any of the source files.

## Code scaffolding

Angular CLI includes powerful code scaffolding tools. To generate a new component, run:

```bash
ng generate component component-name
```

For a complete list of available schematics (such as `components`, `directives`, or `pipes`), run:

```bash
ng generate --help
```

## Building

To build the project run:

```bash
ng build
```

This will compile your project and store the build artifacts in the `dist/` directory. By default, the production build optimizes your application for performance and speed.

## Running unit tests

To execute unit tests with the [Karma](https://karma-runner.github.io) test runner, use the following command:

```bash
ng test
```

## Running end-to-end tests

For end-to-end (e2e) testing, run:

```bash
ng e2e
```

Angular CLI does not come with an end-to-end testing framework by default. You can choose one that suits your needs.

## Additional Resources

For more information on using the Angular CLI, including detailed command references, visit the [Angular CLI Overview and Command Reference](https://angular.dev/tools/cli) page.
