import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-username',
  templateUrl: './username.component.html',
  standalone: false
})
export class UsernameComponent {
  username = '';

  constructor(private router: Router) {}

  submitName() {
    localStorage.setItem('username', this.username);
    this.router.navigate(['/todos']);
  }
}
