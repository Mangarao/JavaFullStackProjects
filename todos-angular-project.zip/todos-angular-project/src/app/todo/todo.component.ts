import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

interface Task {
  id: number;
  name: string;
  completed: boolean;
}

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  standalone: false
})
export class TodoComponent implements OnInit {
  username = '';
  taskName = '';
  tasks: Task[] = [];
  editId: number | null = null;

  constructor(private router: Router) {}

  ngOnInit() {
    const storedUsername = localStorage.getItem('username');
    if (!storedUsername) {
      this.router.navigate(['/']);
    } else {
      this.username = storedUsername;
    }
  }

  addOrUpdateTask() {
    if (!this.taskName.trim()) return;

    if (this.editId !== null) {
      const task = this.tasks.find(t => t.id === this.editId);
      if (task) task.name = this.taskName;
      this.editId = null;
    } else {
      this.tasks.push({ id: Date.now(), name: this.taskName, completed: false });
    }

    this.taskName = '';
  }

  toggleComplete(task: Task) {
    task.completed = !task.completed;
  }

  editTask(task: Task) {
    this.taskName = task.name;
    this.editId = task.id;
  }

  goToTopTodos() {
    this.router.navigate(['/top-todos']);
  }
}
