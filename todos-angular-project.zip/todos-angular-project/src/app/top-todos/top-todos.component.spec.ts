import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TopTodosComponent } from './top-todos.component';

describe('TopTodosComponent', () => {
  let component: TopTodosComponent;
  let fixture: ComponentFixture<TopTodosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TopTodosComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TopTodosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
