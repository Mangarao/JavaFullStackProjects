import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-top-todos',
  templateUrl: './top-todos.component.html',
  standalone:false
})
export class TopTodosComponent implements OnInit {
  topTodos: any[] = [];
  username = '';

  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit() {
    this.username = localStorage.getItem('username') || '';
    this.http.get<any[]>('https://jsonplaceholder.typicode.com/todos?_limit=10')
      .subscribe(data => this.topTodos = data);
  }

  backToTodos() {
    this.router.navigate(['/todos']);
  }
}
