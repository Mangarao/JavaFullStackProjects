import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UsernameComponent } from './username/username.component';
import { TodoComponent } from './todo/todo.component';
import { TopTodosComponent } from './top-todos/top-todos.component';

const routes: Routes = [
  { path: '', component: UsernameComponent },
  { path: 'todos', component: TodoComponent },
  { path: 'top-todos', component: TopTodosComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
