package com.deloitte.servlet.example;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
 private static final long serialVersionUID = 1L;
 private UserDAO userDAO;

 public void init() {
     userDAO = new UserDAO();
 }

 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     String username = request.getParameter("username");
     String password = request.getParameter("password");

     if (userDAO.validate(username, password)) {
    	 response.setContentType("text/html");
         PrintWriter pw = response.getWriter();
         pw.println("Hello, "+username);
         RequestDispatcher dispatcher = request.getRequestDispatcher("welcome");
         //uncomment forward statement code and verify the result
         //dispatcher.forward(request, response);
         dispatcher.include(request, response);
     } else {
         response.sendRedirect("error");
     }
 }
}
