 RequestDispatcher and sendRedirect
Overview of RequestDispatcher and sendRedirect
RequestDispatcher:
The RequestDispatcher interface allows including content from another resource or forwarding the request to another resource within the same server.
Methods:
1.	include(HttpServletRequest request, HttpServletResponse response):
o	Includes content from another resource (servlet, JSP, HTML).
o	Control returns to the original servlet after including the content.
o	Useful for common elements like headers, footers, or navigation bars.
2.	forward(HttpServletRequest request, HttpServletResponse response):
o	Forwards the request to another resource (servlet, JSP, HTML).
o	Control is transferred to the new resource; the original servlet does not regain control.
o	The URL in the browser remains unchanged.
sendRedirect:
The sendRedirect method of the HttpServletResponse interface sends a redirect response to the client using the specified URL.
Characteristics:
•	The client (browser) makes a new request to the specified URL.
•	The URL in the browser changes to the new URL.
•	Can redirect to resources on different servers or contexts.
Real-Time Examples of RequestDispatcher (Summary)
1.	Login Validation: Forward to dashboard on success, or error page on failure.
2.	E-commerce Order Flow: Forward from cart to payment, then to success/failure page.
3.	Student Registration: Forward from registration servlet to validation and then result page.
4.	Contact Form Submission: Forward to thank you or error page after data is processed.
5.	Header/Footer Inclusion: Forward or include header/footer JSPs for consistent layout.
6.	Admin/User Role Redirect: Forward to different dashboards based on user role.
7.	Bank Transaction: Forward to balance verification and then confirmation/error page.
8.	Online Exam Timer: Forward to evaluation if time is left, or timeout page otherwise.
9.	File Upload: Forward to validator servlet, then to success or error page.
10.	Ticket Booking: Forward from booking to availability check, then to payment or unavailable page.
Project Name: Servlet-Demo2
This project covers RequestDispatcher (include, forward methods), sendRedirect methods with real-time use case scenarios.
Real-Time Use Case:
A web application requires user authentication to access certain resources. Users must log in with their credentials (username and password). The application verifies these credentials against a database. If the credentials are valid, the user is granted access to the welcome page. If the credentials are invalid, the user is redirected to an error page.
Components:
•	UserDAO: Reads database connection details from db.properties file and validates the username and password against the users table.
•	LoginServlet: Uses UserDAO to validate the login credentials. If valid, forwards the request to WelcomeServlet. If invalid, redirects to ErrorServlet.
•	WelcomeServlet: Generates the welcome HTML content directly within the servlet.
•	ErrorServlet: Generates the error HTML content directly within the servlet.
•	RequestDispatcher.forward()/include(): Forwards the request from LoginServlet to WelcomeServlet.
•	response.sendRedirect(): Redirects the client to ErrorServlet.
•	db.properties: Configure Database details.
•	login.html: User Interface to enter username and password for login.
SQL Script:
create database mydb;
use mydb;
create table users (username varchar(50) primary key, password varchar(20), email varchar(50));
insert into users values ('manga', 'managa123', 'manga@gmail.com');
Hands-on Tasks:
Task 1: OTP Validation Servlet
•	Generate a fixed OTP (e.g., 1234).
•	Validate entered OTP.
•	Show success or error accordingly.
Task 2: File Upload Validation in Servlet
•	Create a file upload system using Servlets that accepts file uploads, checks if the file type is .pdf or .jpg, and shows a validation message using RequestDispatcher's forward() or include() method.
Validate File Type:
•	Check if the file type is .pdf or .jpg.
•	If valid, save the file to a predefined directory on the server.
•	If invalid, set an error message indicating the allowed file types.
Use RequestDispatcher:
•	Forward the request to a result page or include the result message in the same page.
Task 3: ClockServlet
•	Display current time.
•	Refresh every 5 seconds using meta-refresh or JS.

