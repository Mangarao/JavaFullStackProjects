const options = {
    method: 'GET',
    headers: {
        'X-RapidAPI-Key': '0ed74d6f73msh142d10d2c45dfcfp12e967jsn18a915cfbbbf',
        'X-RapidAPI-Host': 'foreca-weather.p.rapidapi.com',
    },
};
const weatherIconMap = {
    'clear': 'bi-brightness-high',
    'mostly clear': 'bi-brightness-high',
    'partly cloudy': 'bi-cloud-sun',
    'cloudy': 'bi-cloudy',
    'fog': 'bi-cloud-fog',
    'rain': 'bi-cloud-rain',
    'thunder': 'bi-cloud-lightning-rain',
    'snow': 'bi-cloud-snow',
    'sleet': 'bi-cloud-hail',
    'wind': 'bi-wind',
    'hail': 'bi-cloud-hail',
    'mist': 'bi-cloud-fog',
    'storm': 'bi-cloud-lightning',
    'hurricane': 'bi-tornado',
    'tornado': 'bi-tornado',
    'cold': 'bi-thermometer-low',
    'hot': 'bi-thermometer-high',
    'blizzard': 'bi-snow',
    'light rain': 'bi-cloud-drizzle',
    'heavy rain': 'bi-cloud-rain-heavy',
    'light snow': 'bi-cloud-snow',
    'heavy snow': 'bi-cloud-snow-heavy',
    'drizzle': 'bi-cloud-drizzle',
    'showers': 'bi-cloud-rain',
    'flurries': 'bi-cloud-snow',
    'freezing rain': 'bi-cloud-hail',
    'sandstorm': 'bi-wind',
    'dust': 'bi-wind',
    'smoke': 'bi-smoke',
    'haze': 'bi-smog',
    'sprinkle': 'bi-cloud-drizzle',
    'overcast': 'bi-clouds',
    'scattered showers': 'bi-cloud-rain',
    'scattered thunderstorms': 'bi-cloud-lightning-rain',
    'isolated thunderstorms': 'bi-cloud-lightning',
    'isolated showers': 'bi-cloud-drizzle',
  };
  
  
getDetails = async () => {
    let city = document.getElementById("cityName").value;
    console.log(city)
    let response = await fetch(`https://foreca-weather.p.rapidapi.com/location/search/${city}`, options)
    let res = await response.json();
    sendOut(res, city)
}
sendOut = async (res, city) => {
    let locId = null;
    for (loc of res.locations) {
        if (loc.country == "India") {
            locId = loc.id;
            break;
        }
    }
    findWeatherCondition(locId, city)
}

findWeatherCondition = async (locId, city) => {
    weatherDetails = null
    console.log(locId)
    let response = await fetch(`https://foreca-weather.p.rapidapi.com/current/${locId}`, options)
    let res = await response.json()
    displayData(res, city)
}

displayData = (res, city) => {
    console.log()
    iconName = weatherIconMap[res.current.symbolPhrase];
    document.getElementById("temp").innerHTML = `<i class="bi ${iconName}" style="font-size: 400%;"></i><h1>${res.current.temperature}&deg;C</h1>`
    document.getElementById("city").innerHTML = `<h2>${city}</h2>`
    document.getElementById("humiditystats").innerHTML = `<i class="stats-icon bi bi-water" style="font-size: 250%;" aria-hidden="true"></i>
    <span id="hum">${res.current.relHumidity}%<p>Humidity</p></span>`

    document.getElementById("windstats").innerHTML = `<i class="stats-icon bi bi-wind" style="font-size: 250%;" aria-hidden="true"></i>
    <span id="wind" >${res.current.windSpeed}Km/hr<p>Wind Speed</p></span>`;
}


