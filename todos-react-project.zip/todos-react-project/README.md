

Step-by-Step Installation
1. Create a New React App
Open your terminal/command prompt and run:
npx create-react-app todo-app
cd todo-app

2. Install React Router
npm install react-router-dom

3. Set Up Your Files
Replace or create the following files inside the src/ directory:

App.js → Main router setup

UsernameScreen.js → For entering user name

TodoScreen.js → Todo list logic

TopTodos.js → Top 10 Todos from JSONPlaceholder

⚠️ Make sure to remove unused files like App.test.js, logo.svg, etc., for a cleaner structure.

4. Add bootstrap
add the below code to index.htmjl
    <link
  href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
  rel="stylesheet"
/>


# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

The page will reload when you make changes.\
You may also see any lint errors in the console.

### `npm test`

Launches the test runner in the interactive watch mode.\
See the section about [running tests](https://facebook.github.io/create-react-app/docs/running-tests) for more information.

### `npm run build`

Builds the app for production to the `build` folder.\
It correctly bundles React in production mode and optimizes the build for the best performance.

Step-by-step guide to deploy your React application to an Amazon S3 bucket and make it publicly accessible.

Summary of Key Steps:
1.	Build your React app (npm run build).
2.	Create an S3 bucket and configure for static website hosting.
3.	Upload the build/ folder to the bucket.
4.	Set permissions for public access via bucket policy.
5.	Configure static website hosting in the S3 bucket settings.
6.	Access your website using the S3 endpoint URL or configure a custom domain.
Follow the Detailed steps here:

Step 1: Build the React Application
Before deploying, we need to build the optimized production version of your React app.
1.	Open the terminal/command prompt in your project directory.
2.	Run the following command to build the production version of your app:
npm run build
This will create a build/ directory containing the static files of your React application, including HTML, CSS, and JS files optimized for production.
Step 2: Create an S3 Bucket
1.	Sign in to your AWS Management Console.
2.	Navigate to S3 by typing "S3" in the search bar and selecting it.
3.	Click on the Create bucket button.
4.	Set the Bucket Name (e.g., my-react-app) which should be unique and select a region (choose the closest region to your users).
5.	In the Bucket Settings for Block Public Access, uncheck the option that blocks all public access, as we want the files to be publicly accessible.
6.	Click on Create Bucket.
Step 3: Upload Your Build Files to the S3 Bucket
1.	Go to the S3 Dashboard.
2.	Select the newly created bucket.
3.	Click on Upload.
4.	In the Upload window, click Add files and select all the files from your build/ folder (everything inside the build directory should be uploaded).
5.	Click on Next and then Upload to complete the upload process.
Step 4: Set Permissions for Public Access
1.	Once the files are uploaded, select your bucket and go to the Permissions tab.
2.	In the Bucket Policy section, click Edit.
3.	Add the following policy to allow public access to the files in your S3 bucket. Replace your-bucket-name with the name of your bucket:
Json:
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "PublicReadGetObject",
      "Effect": "Allow",
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::your-bucket-name/*",
      "Principal": "*"
    }
  ]
}
4.	Save policy
Step 5: Configure Bucket for Static Website Hosting
1.	Go to the Properties tab of your S3 bucket.
2.	Scroll down to the Static website hosting section and click Edit.
3.	Select Enable.
4.	In the Index document field, enter index.html.
5.	In the Error document field, enter index.html (this will help with routing for single-page apps).
6.	Click Save changes.
Step 6: Access Your Website
1.	Once the bucket is configured for static website hosting, you’ll see an endpoint URL under the Static website hosting section (it will look like http://your-bucket-name.s3-website-region.amazonaws.com).
2.	You can now access your React app by navigating to this URL.
Step 7: (Optional) Set up a Custom Domain (Optional)
To use a custom domain for your React app, you need to:
1.	Purchase or set up a domain (e.g., through Route 53 or any other domain registrar).
2.	In your domain registrar's DNS settings, create a CNAME record pointing to your S3 website endpoint.
For example, if you want your website to be accessible via www.yourdomain.com, create a CNAME record like this:
Name: www
Value: your-bucket-name.s3-website-region.amazonaws.com
1.	Once the DNS settings propagate (it can take up to 48 hours), your website should be accessible through your custom domain.
Step 8: (Optional) Use CloudFront for SSL and Faster Access (Optional)
If you'd like your React app to be accessible via HTTPS, you can use Amazon CloudFront to create a CDN (Content Delivery Network) distribution:
1.	Go to CloudFront in the AWS Management Console.
2.	Click Create Distribution.
3.	Choose Web and set the Origin Domain Name to your S3 bucket’s website endpoint.
4.	Set up an SSL certificate (you can use Amazon’s ACM for a free SSL certificate).
5.	Once the CloudFront distribution is created, you’ll get a new URL (it will look something like d1234abcd.cloudfront.net). You can then point your custom domain to this CloudFront URL.


